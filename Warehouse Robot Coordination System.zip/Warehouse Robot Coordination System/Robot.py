import pygame
import random
from collections import deque

# Initialize Pygame
pygame.init()

# Window dimensions
WIDTH, HEIGHT = 600, 600
ROWS, COLS = 20, 20  # Grid size
CELL_SIZE = WIDTH // COLS

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
GRAY = (200, 200, 200)

# Screen setup
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Robot Coordination Simulation")

# Font setup
font = pygame.font.SysFont("Arial", 20)

# Clock to control frame rate
clock = pygame.time.Clock()

# Define multiple unique colors for each robot
robot_colors = [BLUE, GREEN, RED, YELLOW, CYAN, MAGENTA]

# Robot class
class Robot:
    def __init__(self, robot_id, start_pos, color):
        self.robot_id = robot_id  # Unique ID for each robot
        self.position = start_pos  # Current position (row, col)
        self.color = color  # Unique color for each robot
        self.task = None  # (start, destination) -> Task: move from start to destination
        self.path = []  # List of positions to follow (calculated by BFS)
        self.active = False  # Whether the robot is moving

    def assign_task(self, start, destination):
        self.task = (start, destination)
        self.active = True
        self.path = bfs(self.position, start) + bfs(start, destination)  # Find path

        # Print task assignment in terminal
        print(f"Robot {self.robot_id} assigned task: Pick from {start}, deliver to {destination}")

    def move(self):
        if self.path:
            self.position = self.path.pop(0)
            # Print the current position in terminal
            print(f"Robot {self.robot_id} moving to {self.position}")
        else:
            if self.active:
                print(f"Robot {self.robot_id} completed its task!")
            self.active = False

# BFS (Breadth-First Search) for pathfinding
def bfs(start, goal):
    queue = deque([[start]])
    visited = set([start])
    
    while queue:
        path = queue.popleft()
        current = path[-1]

        if current == goal:
            return path[1:]  # Exclude the current position

        for neighbor in get_neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(path + [neighbor])

    return []  # No path found

# Get valid neighbors (up, down, left, right)
def get_neighbors(pos):
    row, col = pos
    neighbors = []
    
    if row > 0:
        neighbors.append((row - 1, col))  # Up
    if row < ROWS - 1:
        neighbors.append((row + 1, col))  # Down
    if col > 0:
        neighbors.append((row, col - 1))  # Left
    if col < COLS - 1:
        neighbors.append((row, col + 1))  # Right
    
    return neighbors

# Draw the grid
def draw_grid():
    for row in range(ROWS):
        for col in range(COLS):
            rect = pygame.Rect(col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(screen, GRAY, rect, 1)  # Draw grid cells

# Draw the robots
def draw_robots(robots):
    for robot in robots:
        row, col = robot.position
        pygame.draw.rect(screen, robot.color, (col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE))
        # Display robot ID
        text = font.render(str(robot.robot_id), True, WHITE)
        screen.blit(text, (col * CELL_SIZE + CELL_SIZE // 4, row * CELL_SIZE + CELL_SIZE // 4))

# Draw task status on the side
def draw_task_status(robots):
    start_x = WIDTH + 10
    start_y = 10
    for robot in robots:
        status = f"Robot {robot.robot_id}: Position {robot.position}, "
        status += "Active" if robot.active else "Idle"
        task_text = font.render(status, True, BLACK)
        screen.blit(task_text, (start_x, start_y))
        start_y += 30  # Space between robot statuses

# Main simulation loop
def main():
    # Initialize robots with unique IDs and random starting positions
    robots = [Robot(i + 1, (random.randint(0, ROWS - 1), random.randint(0, COLS - 1)), robot_colors[i]) for i in range(len(robot_colors))]

    # Assign initial tasks to robots
    for robot in robots:
        start = (random.randint(0, ROWS - 1), random.randint(0, COLS - 1))
        destination = (random.randint(0, ROWS - 1), random.randint(0, COLS - 1))
        robot.assign_task(start, destination)

    running = True
    while running:
        clock.tick(10)  # Control frame rate (10 FPS)

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Clear the screen
        screen.fill(WHITE)

        # Draw grid
        draw_grid()

        # Update and draw robots
        for robot in robots:
            if robot.active:
                robot.move()
            draw_robots(robots)

        # Draw task status
        draw_task_status(robots)

        # Update display
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
