import pygame
import random
from collections import deque

# Initialize Pygame
pygame.init()

# Window dimensions
WIDTH, HEIGHT = 600, 600
ROWS, COLS = 20, 20  # Grid size
CELL_SIZE = WIDTH // COLS

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
GRAY = (200, 200, 200)
OBSTACLE_COLOR = (50, 50, 50)

# Screen setup
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Robot Coordination Simulation with Obstacles")

# Font setup
font = pygame.font.SysFont("Arial", 20)

# Clock to control frame rate
clock = pygame.time.Clock()

# Define colors for the four robots
robot_colors = [BLUE, GREEN, RED, YELLOW]

# Obstacles
obstacles = {(5, 5), (10, 10), (15, 15), (7, 12), (14, 3)}  # Example obstacle positions

# Robot class
class Robot:
    def __init__(self, robot_id, start_pos, color):
        self.robot_id = robot_id  # Unique ID for each robot
        self.position = start_pos  # Current position (row, col)
        self.color = color  # Unique color for each robot
        self.task = None  # (start, destination) -> Task: move from start to destination
        self.path = []  # List of positions to follow (calculated by BFS)
        self.active = False  # Whether the robot is moving
        self.move_delay = 0  # Delay counter for slow movement
        self.blocked_positions = set()  # To track positions that are blocked by obstacles

    def assign_task(self, start, destination):
        self.task = (start, destination)
        self.active = True
        self.blocked_positions.clear()  # Clear any previous blocked positions
        self.path = bfs(self.position, start) + bfs(start, destination)  # Find path
        print(f"Robot {self.robot_id} assigned task: Pick from {start}, deliver to {destination}")

    def move(self, robots):
        if self.path and self.move_delay == 0:  # Move only when delay counter is zero
            next_position = self.path[0]
            if not is_position_occupied(next_position, robots) and next_position not in obstacles:
                self.position = self.path.pop(0)
                print(f"Robot {self.robot_id} moving to {self.position}")
            else:
                # Robot is blocked, handle the obstacle
                print(f"Robot {self.robot_id} blocked at {next_position}, recalculating path...")
                self.blocked_positions.add(next_position)
                # Recalculate path while avoiding blocked positions and obstacles
                self.path = bfs(self.position, self.task[1], self.blocked_positions)

                if not self.path:
                    print(f"Robot {self.robot_id} cannot find an alternative path, retrying...")

        if self.move_delay > 0:
            self.move_delay -= 1  # Decrease delay counter
        else:
            self.move_delay = 5  # Reset delay for slower movement

        if not self.path and self.active:
            print(f"Robot {self.robot_id} completed its task!")
            self.active = False

# BFS (Breadth-First Search) for pathfinding with obstacle avoidance
def bfs(start, goal, blocked_positions=None):
    if blocked_positions is None:
        blocked_positions = set()

    queue = deque([[start]])
    visited = set([start])
    
    while queue:
        path = queue.popleft()
        current = path[-1]

        if current == goal:
            return path[1:]  # Exclude the current position

        for neighbor in get_neighbors(current):
            if neighbor not in visited and neighbor not in obstacles and neighbor not in blocked_positions:
                visited.add(neighbor)
                queue.append(path + [neighbor])

    return []  # No path found

# Get valid neighbors (up, down, left, right)
def get_neighbors(pos):
    row, col = pos
    neighbors = []
    
    if row > 0:
        neighbors.append((row - 1, col))  # Up
    if row < ROWS - 1:
        neighbors.append((row + 1, col))  # Down
    if col > 0:
        neighbors.append((row, col - 1))  # Left
    if col < COLS - 1:
        neighbors.append((row, col + 1))  # Right
    
    return neighbors

# Check if a position is occupied by any robot
def is_position_occupied(pos, robots):
    for robot in robots:
        if robot.position == pos:
            return True
    return False

# Draw the grid
def draw_grid():
    for row in range(ROWS):
        for col in range(COLS):
            rect = pygame.Rect(col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(screen, GRAY, rect, 1)  # Draw grid cells

# Draw the robots
def draw_robots(robots):
    for robot in robots:
        row, col = robot.position
        pygame.draw.rect(screen, robot.color, (col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE))
        text = font.render(str(robot.robot_id), True, WHITE)
        screen.blit(text, (col * CELL_SIZE + CELL_SIZE // 4, row * CELL_SIZE + CELL_SIZE // 4))

# Draw the obstacles
def draw_obstacles():
    for row, col in obstacles:
        pygame.draw.rect(screen, OBSTACLE_COLOR, (col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE))

# Draw task status on the side
def draw_task_status(robots):
    start_x = WIDTH + 10
    start_y = 10
    for robot in robots:
        status = f"Robot {robot.robot_id}: Position {robot.position}, "
        status += "Active" if robot.active else "Idle"
        task_text = font.render(status, True, BLACK)
        screen.blit(task_text, (start_x, start_y))
        start_y += 30  # Space between robot statuses

# Main simulation loop
def main():
    random.seed(42)  # Seed for consistency

    # Initialize four robots with unique IDs and random starting positions
    robots = [Robot(i + 1, (random.randint(0, ROWS - 1), random.randint(0, COLS - 1)), robot_colors[i]) for i in range(len(robot_colors))]

    # Assign initial tasks to robots
    for robot in robots:
        start = (random.randint(0, ROWS - 1), random.randint(0, COLS - 1))
        destination = (random.randint(0, ROWS - 1), random.randint(0, COLS - 1))
        robot.assign_task(start, destination)

    running = True
    while running:
        clock.tick(10)  # Control frame rate (10 FPS)

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Clear the screen
        screen.fill(WHITE)

        # Draw grid
        draw_grid()

        # Draw obstacles
        draw_obstacles()

        # Update and draw robots
        for robot in robots:
            if robot.active:
                robot.move(robots)
            draw_robots(robots)

        # Draw task status
        draw_task_status(robots)

        # Update display
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
